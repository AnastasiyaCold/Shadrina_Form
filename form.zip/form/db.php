<?php
$pdo = new PDO(
    'mysql:host=localhost;dbname=form1;charset=utf8',
    'root',
    '');
$login = $_POST['login'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$stmt = $pdo->query("INSERT INTO `f1` (login,email,phone,password) VALUES ('$login','$email','$phone','$password')");
if ($stmt == true){
    echo "Информация занесена в бд.";
}else{
    echo "Информация не занесена в бд.";
}
