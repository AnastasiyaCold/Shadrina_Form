<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<form name="form" method="get" action="db.php">
    Логин:<br/>
    <input name="login" type="text" size="25" maxlength="30" value=""/><br/>
    Email:<br/>
    <input name="email" type="email" size="25" maxlength="30" value=""/><br/>
    Телефон:<br/>
    <input name="phone" type="text" size="25" maxlength="30" value=""/><br/>
    Пароль:<br/>
    <input name="password" type="password" size="25" maxlength="30" value=""/><br/>
    <input type="submit" name="enter" value="Регистрация"/>
</form>
</body>
</html>
