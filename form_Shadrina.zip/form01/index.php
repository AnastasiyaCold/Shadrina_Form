<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<form name="form" method="post" action="db.php">
    Логин:<br/>
    <input name="login" type="text" size="25" maxlength="30" value=""/><br/>
    Пароль:<br/>
    <input name="password" type="password" size="25" maxlength="30" value=""/><br/>
    <input type="submit" name="enter" value="Вход"/>
</form>
</body>
</html>
